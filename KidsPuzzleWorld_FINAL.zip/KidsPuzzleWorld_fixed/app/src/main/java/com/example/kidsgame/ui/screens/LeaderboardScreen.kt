package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class LeaderboardUi(val rank: String, val name: String, val score: Int)

@Composable
fun LeaderboardScreen(navController: NavController) {
    val entries = listOf(
        LeaderboardUi("🥇", "أحمد الصغير", 12500),
        LeaderboardUi("🥈", "سارة الذكية", 12000),
        LeaderboardUi("🥉", "خالد المحترف", 9800),
        LeaderboardUi("4️⃣", "نور", 7500),
        LeaderboardUi("5️⃣", "ليلى", 6200),
        LeaderboardUi("6️⃣", "يوسف", 5000),
        LeaderboardUi("7️⃣", "مريم", 4000)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🏆 لوحة الصدارة") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(entries) { entry ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (entry.rank == "🥇") MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(entry.rank, fontSize = 24.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(entry.name, style = MaterialTheme.typography.titleMedium)
                        }
                        Text("⭐ ${entry.score}", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
