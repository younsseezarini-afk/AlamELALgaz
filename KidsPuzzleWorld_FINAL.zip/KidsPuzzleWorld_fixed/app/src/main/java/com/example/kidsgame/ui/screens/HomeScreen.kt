package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class GameTile(val icon: String, val title: String, val route: String)

@Composable
fun HomeScreen(navController: NavController) {
    val userName = "أحمد"
    val stars = 1250
    val coins = 3520
    val level = 12
    val streak = 3

    val games = listOf(
        GameTile("📝", "كلمات", "game/words"),
        GameTile("🧮", "حساب", "game/math"),
        GameTile("🧩", "منطق", "game/logic"),
        GameTile("🖼️", "صور", "game/picture"),
        GameTile("♟️", "شطرنج", "chess"),
        GameTile("🧠", "ذاكرة", "memory"),
        GameTile("⚡", "حساب سريع", "quickmath"),
        GameTile("📖", "قصص", "stories"),
        GameTile("🎨", "رسم", "drawing"),
        GameTile("🏆", "إنجازات", "achievements"),
        GameTile("📊", "صدارة", "leaderboard"),
        GameTile("👤", "ملفي", "profile")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎮 عالم الألغاز والمرح", style = MaterialTheme.typography.titleLarge) },
                actions = {
                    IconButton(onClick = { navController.navigate("profile") }) {
                        Icon(Icons.Default.Person, contentDescription = "الملف الشخصي")
                    }
                    IconButton(onClick = { navController.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(8.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧸 $userName", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("⭐ $stars", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                            Text("🪙 $coins", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.titleMedium)
                            Text("📈 المستوى $level", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔥 سلسلة الأيام: $streak")
                        TextButton(onClick = { navController.navigate("dailyBonus") }) { Text("استلام المكافأة 🎁") }
                    }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth().height(560.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(games) { game ->
                        Card(
                            onClick = { navController.navigate(game.route) },
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(game.icon, style = MaterialTheme.typography.displaySmall)
                                Text(game.title, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}
