package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class StoryUi(val emoji: String, val title: String, val content: String)

@Composable
fun StoryScreen(navController: NavController) {
    val stories = listOf(
        StoryUi("🐢", "السلحفاة الصغيرة", "كانت هناك سلحفاة صغيرة تعيش في بركة هادئة..."),
        StoryUi("🦋", "الفراشة الجميلة", "في حديقة ملونة، ولدت فراشة صغيرة من شرنقة ذهبية..."),
        StoryUi("🐰", "الأرنب الذكي", "في الغابة، عاش أرنب ذكي يحل جميع المشاكل..."),
        StoryUi("🐝", "النحلة المجتهدة", "كانت نحلة تجمع الرحيق من الأزهار طوال اليوم...")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📖 قصص") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(stories) { story ->
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(story.emoji, fontSize = 40.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(story.title, style = MaterialTheme.typography.titleLarge)
                            Text(story.content, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = {}) { Text("اقرأ المزيد") }
                        }
                    }
                }
            }
        }
    }
}
