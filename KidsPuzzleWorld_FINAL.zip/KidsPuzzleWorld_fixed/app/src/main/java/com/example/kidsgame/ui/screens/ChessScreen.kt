package com.example.kidsgame.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.kidsgame.chess.ChessEngine
import com.example.kidsgame.chess.Piece
import com.example.kidsgame.chess.PieceType
import com.example.kidsgame.chess.Color as ChessColor
import com.example.kidsgame.ui.theme.*

@Composable
fun ChessScreen(navController: NavController) {
    val engine = remember { ChessEngine() }
    var selectedRow by remember { mutableStateOf(-1) }
    var selectedCol by remember { mutableStateOf(-1) }
    var moveHistory by remember { mutableStateOf(listOf<String>()) }
    var gameState by remember { mutableStateOf("قم بنقلتك") }
    var sound by remember { mutableStateOf(true) }

    // ألوان الخشب
    val boardLight = Color(0xFFDEB887)
    val boardDark = Color(0xFF6B4226)
    val woodBorder = Color(0xFF8B5A2B)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("♟️ الشطرنج", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Text("⬅️", fontSize = 20.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { engine.reset(); selectedRow = -1; selectedCol = -1; gameState = "قم بنقلتك" }) {
                        Text("🔄", fontSize = 20.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = woodBorder)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Brush.verticalGradient(listOf(Color(0xFF8B5A2B), Color(0xFF5D3A1A))))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // شريط الحالة
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("🔵 $gameState", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (engine.currentTurn == ChessColor.WHITE) "🌕 أبيض" else "🌑 أسود",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (engine.currentTurn == ChessColor.WHITE) Color(0xFF8D6E63) else Color.Black
                    )
                }
            }

            // لوحة الشطرنج
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .shadow(8.dp, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(woodBorder)
                    .padding(4.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (row in 0..7) {
                        Row(modifier = Modifier.weight(1f)) {
                            for (col in 0..7) {
                                val piece = engine.getPiece(row, col)
                                val isSelected = row == selectedRow && col == selectedCol
                                val isDark = (row + col) % 2 == 1
                                val cellColor = if (isDark) boardDark else boardLight

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .background(if (isSelected) Color.Yellow.copy(alpha = 0.5f) else cellColor)
                                        .border(1.dp, Color.Black.copy(alpha = 0.2f))
                                        .clickable {
                                            if (selectedRow == -1) {
                                                if (piece != null && piece.color == engine.currentTurn) {
                                                    selectedRow = row
                                                    selectedCol = col
                                                }
                                            } else {
                                                val moved = engine.makeMove(selectedRow, selectedCol, row, col)
                                                if (moved) {
                                                    selectedRow = -1
                                                    selectedCol = -1
                                                    gameState = if (engine.gameOver) "كش ملك!" else "قم بنقلتك"
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (piece != null) {
                                        ChessPiece(piece)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // شريط معلومات القطع المأسورة
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Text("♟️ الأبيض: 8", color = Color.White, fontSize = 16.sp)
                Text("♞ الأسود: 8", color = Color.White, fontSize = 16.sp)
            }

            // أزرار المساعدة
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { selectedRow = -1; selectedCol = -1; gameState = "قم بنقلتك" }) {
                    Text("إلغاء")
                }
                Button(onClick = { navController.popBackStack() }) {
                    Text("خروج")
                }
            }
        }
    }
}

@Composable
fun ChessPiece(piece: Piece) {
    val color = if (piece.color == ChessColor.WHITE) Color.White else Color.Black
    val shadowColor = if (piece.color == ChessColor.WHITE) Color(0xFFBDBDBD) else Color(0xFF424242)

    when (piece.type) {
        PieceType.KING -> Text("♚", fontSize = 32.sp, color = color)
        PieceType.QUEEN -> Text("♛", fontSize = 32.sp, color = color)
        PieceType.ROOK -> Text("♜", fontSize = 32.sp, color = color)
        PieceType.BISHOP -> Text("♝", fontSize = 32.sp, color = color)
        PieceType.KNIGHT -> Text("♞", fontSize = 32.sp, color = color)
        PieceType.PAWN -> Text("♟", fontSize = 32.sp, color = color)
    }
}
