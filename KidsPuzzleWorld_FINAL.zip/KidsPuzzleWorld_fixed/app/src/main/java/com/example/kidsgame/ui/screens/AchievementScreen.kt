package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

data class AchievementUi(val icon: String, val name: String, val description: String, val unlocked: Boolean)

@Composable
fun AchievementScreen(navController: NavController) {
    val achievements = listOf(
        AchievementUi("🌟", "البداية", "أكمل أول لغز", true),
        AchievementUi("🏆", "المثابر", "أكمل 10 ألغاز", true),
        AchievementUi("⭐", "النجم", "اجمع 50 نجمة", true),
        AchievementUi("👑", "البطل", "اجمع 100 نجمة", false),
        AchievementUi("🧠", "المحترف", "أكمل 20 لغزاً", true),
        AchievementUi("🎓", "العبقري", "أكمل 50 لغزاً", false),
        AchievementUi("♟️", "سيد الشطرنج", "الفوز في 5 مباريات شطرنج", false),
        AchievementUi("🧩", "ملك الذاكرة", "أكمل 10 جولات ذاكرة", false)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🏆 الإنجازات") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(achievements) { achievement ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (achievement.unlocked) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(achievement.icon, fontSize = 28.sp)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(achievement.name, style = MaterialTheme.typography.titleMedium)
                                Text(achievement.description, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text(if (achievement.unlocked) "✅" else "🔒", fontSize = 24.sp)
                    }
                }
            }
        }
    }
}
