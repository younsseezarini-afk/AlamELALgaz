package com.example.kidsgame.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MemoryGameScreen(navController: NavController) {
    val emojis = listOf("🍎", "🚗", "🐱", "🌙", "⭐", "🎈", "🐟", "🍕")
    val cards = remember { (emojis + emojis).shuffled() }
    var revealed by remember { mutableStateOf<List<Int>>(emptyList()) }
    var matched by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var moves by remember { mutableStateOf(0) }
    var isProcessing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🧠 لعبة الذاكرة") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("المحاولات: $moves")
                    Text("المطابقات: ${matched.size / 2} / ${emojis.size}")
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                contentPadding = PaddingValues(4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cards.size) { index ->
                    val isRevealed = index in revealed || index in matched
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clickable {
                                if (isRevealed || isProcessing || revealed.size >= 2) return@clickable
                                val next = revealed + index
                                revealed = next
                                if (next.size == 2) {
                                    moves++
                                    isProcessing = true
                                    val (i1, i2) = next
                                    if (cards[i1] == cards[i2]) {
                                        matched = matched + i1 + i2
                                        revealed = emptyList()
                                        isProcessing = false
                                    } else {
                                        scope.launch {
                                            delay(800)
                                            revealed = emptyList()
                                            isProcessing = false
                                        }
                                    }
                                }
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRevealed) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(if (isRevealed) cards[index] else "؟", fontSize = 32.sp)
                        }
                    }
                }
            }
        }
    }
}
