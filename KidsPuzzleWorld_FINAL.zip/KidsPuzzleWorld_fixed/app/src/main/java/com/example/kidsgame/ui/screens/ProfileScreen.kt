package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun ProfileScreen(navController: NavController) {
    var userName by remember { mutableStateOf("أحمد") }
    var stars by remember { mutableStateOf(1250) }
    var coins by remember { mutableStateOf(3520) }
    var level by remember { mutableStateOf(12) }
    var exp by remember { mutableStateOf(85) }
    var streak by remember { mutableStateOf(3) }
    var gamesPlayed by remember { mutableStateOf(45) }
    var gamesCorrect by remember { mutableStateOf(38) }
    var percentage by remember { mutableStateOf((gamesCorrect * 100) / maxOf(gamesPlayed, 1)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("👤 الملف الشخصي") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // الصورة والاسم
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🧸", fontSize = 64.sp)
                    Text(userName, style = MaterialTheme.typography.headlineSmall)
                    Text("المستوى $level", style = MaterialTheme.typography.titleMedium)
                }
            }

            Spacer(Modifier.height(16.dp))

            // إحصائيات سريعة
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatItem("⭐", "$stars", "النجوم")
                StatItem("🪙", "$coins", "العملات")
                StatItem("🔥", "$streak", "الأيام")
            }

            Spacer(Modifier.height(16.dp))

            // النسبة المئوية
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("نسبة الإنجاز: $percentage%")
                    LinearProgressIndicator(progress = percentage / 100f, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("الألعاب المكتملة: $gamesPlayed", style = MaterialTheme.typography.bodyMedium)
                    Text("الإجابات الصحيحة: $gamesCorrect", style = MaterialTheme.typography.bodyMedium)
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { navController.navigate("achievements") }) {
                    Text("🏆 الإنجازات")
                }
                Button(onClick = { navController.navigate("leaderboard") }) {
                    Text("📊 الصدارة")
                }
            }
        }
    }
}

@Composable
fun StatItem(emoji: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 32.sp)
        Text(value, style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
