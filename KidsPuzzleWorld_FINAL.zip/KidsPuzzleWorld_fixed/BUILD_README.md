# KidsPuzzleWorld — fixed build

تم إصلاح أخطاء Kotlin التي كانت تمنع مهمة `:app:compileDebugKotlin` من الاكتمال، خصوصاً:

- AchievementScreen: استبدال Triple غير الصحيح ببيانات من 4 حقول.
- StoryScreen: إصلاح بنية بيانات القصص.
- HomeScreen: إصلاح بنية بيانات الألعاب ومسارات التنقل وأيقونات Material.
- ChessScreen: حل تعارض `Color` بين Compose ومحرك الشطرنج.
- DrawingScreen: إصلاح imports الخاصة بالرسم واللمس والألوان وحالة المسارات.
- MemoryGameScreen: إصلاح أنواع Mutable/List/Set وإدارة coroutine بدلاً من GlobalScope.
- ProfileScreen: إصلاح `LinearProgressIndicator` وإضافة `sp`.
- LeaderboardScreen و QuickMathScreen: إصلاح `sp`.
- إزالة اعتماد Hilt من نسخة المشروع لتبسيط البناء، مع إنشاء PreferencesManager و GameRepository مباشرة في MainActivity.

للبناء:

```bash
./gradlew assembleDebug
```

ملف APK الناتج سيكون عادةً في:

`app/build/outputs/apk/debug/app-debug.apk`
