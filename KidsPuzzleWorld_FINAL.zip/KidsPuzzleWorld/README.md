# KidsPuzzleWorld

مشروع Android/Kotlin + Jetpack Compose للعبة تعليمية للأطفال.

## البناء محلياً

```bash
chmod +x ./gradlew
./gradlew assembleDebug
```

سيظهر APK هنا:

`app/build/outputs/apk/debug/app-debug.apk`

## البناء على GitHub Actions

ارفع المشروع إلى GitHub ثم افتح تبويب **Actions** واختر **Build KidsPuzzleWorld APK** واضغط **Run workflow**. كما سيعمل البناء تلقائياً عند push إلى `main` أو `master`.

الـ APK الناتج يُرفع كـ Artifact باسم `KidsPuzzleWorld-debug-apk`.

## التقنية

- Android Gradle Plugin 8.2.2
- Kotlin 1.9.20
- Jetpack Compose
- Compile/Target SDK 34
- Java 17
- Room + DataStore + Navigation Compose
