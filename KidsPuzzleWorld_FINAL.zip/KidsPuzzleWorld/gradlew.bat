@echo off
setlocal
set "GRADLE_VERSION=8.2"
set "GRADLE_USER_HOME=%GRADLE_USER_HOME%"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_ROOT=%GRADLE_USER_HOME%\wrapper\dists\kidspuzzle-gradle-%GRADLE_VERSION%"
set "GRADLE_HOME=%DIST_ROOT%\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%DIST_ROOT%" mkdir "%DIST_ROOT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%DIST_ROOT%\gradle-%GRADLE_VERSION%-bin.zip'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ROOT%\gradle-%GRADLE_VERSION%-bin.zip' '%DIST_ROOT%\tmp'"
move /Y "%DIST_ROOT%\tmp\gradle-%GRADLE_VERSION%" "%GRADLE_HOME%" >nul
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
