package com.example.kidsgame.chess

import kotlin.math.abs

// ==== تمثيل القطع ====
enum class PieceType { KING, QUEEN, ROOK, BISHOP, KNIGHT, PAWN }

enum class Color { WHITE, BLACK }

data class Piece(
    val type: PieceType,
    val color: Color
) {
    override fun toString(): String {
        val symbol = when (type) {
            PieceType.KING -> "K"
            PieceType.QUEEN -> "Q"
            PieceType.ROOK -> "R"
            PieceType.BISHOP -> "B"
            PieceType.KNIGHT -> "N"
            PieceType.PAWN -> "P"
        }
        return if (color == Color.WHITE) symbol.lowercase() else symbol
    }
}

data class Move(val fromRow: Int, val fromCol: Int, val toRow: Int, val toCol: Int)

class ChessEngine {
    var board: Array<Array<Piece?>> = Array(8) { Array(8) { null } }
    var currentTurn: Color = Color.WHITE
    var gameOver: Boolean = false
    var winner: Color? = null

    init {
        setupBoard()
    }

    fun setupBoard() {
        board = Array(8) { Array(8) { null } }

        // القطع السوداء
        board[0][0] = Piece(PieceType.ROOK, Color.BLACK)
        board[0][1] = Piece(PieceType.KNIGHT, Color.BLACK)
        board[0][2] = Piece(PieceType.BISHOP, Color.BLACK)
        board[0][3] = Piece(PieceType.QUEEN, Color.BLACK)
        board[0][4] = Piece(PieceType.KING, Color.BLACK)
        board[0][5] = Piece(PieceType.BISHOP, Color.BLACK)
        board[0][6] = Piece(PieceType.KNIGHT, Color.BLACK)
        board[0][7] = Piece(PieceType.ROOK, Color.BLACK)
        for (c in 0..7) board[1][c] = Piece(PieceType.PAWN, Color.BLACK)

        // القطع البيضاء
        board[7][0] = Piece(PieceType.ROOK, Color.WHITE)
        board[7][1] = Piece(PieceType.KNIGHT, Color.WHITE)
        board[7][2] = Piece(PieceType.BISHOP, Color.WHITE)
        board[7][3] = Piece(PieceType.QUEEN, Color.WHITE)
        board[7][4] = Piece(PieceType.KING, Color.WHITE)
        board[7][5] = Piece(PieceType.BISHOP, Color.WHITE)
        board[7][6] = Piece(PieceType.KNIGHT, Color.WHITE)
        board[7][7] = Piece(PieceType.ROOK, Color.WHITE)
        for (c in 0..7) board[6][c] = Piece(PieceType.PAWN, Color.WHITE)

        currentTurn = Color.WHITE
        gameOver = false
        winner = null
    }

    fun getPiece(row: Int, col: Int): Piece? = board[row][col]

    fun isLegalMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int): Boolean {
        val piece = board[fromRow][fromCol] ?: return false
        if (piece.color != currentTurn) return false
        if (fromRow == toRow && fromCol == toCol) return false
        if (toRow !in 0..7 || toCol !in 0..7) return false

        val target = board[toRow][toCol]
        if (target?.color == piece.color) return false

        // التحرك حسب نوع القطعة
        when (piece.type) {
            PieceType.PAWN -> {
                val dir = if (piece.color == Color.WHITE) -1 else 1
                val startRow = if (piece.color == Color.WHITE) 6 else 1
                // تقدم مربع واحد
                if (toCol == fromCol && toRow == fromRow + dir && board[toRow][toCol] == null) return true
                // تقدم مربعين من البداية
                if (fromRow == startRow && toCol == fromCol && toRow == fromRow + 2 * dir && board[fromRow + dir][fromCol] == null && board[toRow][toCol] == null) return true
                // أسر قطري
                if (abs(toCol - fromCol) == 1 && toRow == fromRow + dir && target != null) return true
                // الأسر بالمرور (En passant) - مبسط
                return false
            }
            PieceType.ROOK -> {
                if (fromRow != toRow && fromCol != toCol) return false
                return isPathClear(fromRow, fromCol, toRow, toCol)
            }
            PieceType.BISHOP -> {
                if (abs(fromRow - toRow) != abs(fromCol - toCol)) return false
                return isPathClear(fromRow, fromCol, toRow, toCol)
            }
            PieceType.KNIGHT -> {
                val rowDiff = abs(fromRow - toRow)
                val colDiff = abs(fromCol - toCol)
                return (rowDiff == 2 && colDiff == 1) || (rowDiff == 1 && colDiff == 2)
            }
            PieceType.QUEEN -> {
                val isRook = fromRow == toRow || fromCol == toCol
                val isBishop = abs(fromRow - toRow) == abs(fromCol - toCol)
                return (isRook || isBishop) && isPathClear(fromRow, fromCol, toRow, toCol)
            }
            PieceType.KING -> {
                val rowDiff = abs(fromRow - toRow)
                val colDiff = abs(fromCol - toCol)
                return rowDiff <= 1 && colDiff <= 1
            }
        }
        return false
    }

    private fun isPathClear(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int): Boolean {
        val rowStep = if (toRow > fromRow) 1 else if (toRow < fromRow) -1 else 0
        val colStep = if (toCol > fromCol) 1 else if (toCol < fromCol) -1 else 0
        var r = fromRow + rowStep
        var c = fromCol + colStep
        while (r != toRow || c != toCol) {
            if (board[r][c] != null) return false
            r += rowStep
            c += colStep
        }
        return true
    }

    fun makeMove(fromRow: Int, fromCol: Int, toRow: Int, toCol: Int): Boolean {
        if (!isLegalMove(fromRow, fromCol, toRow, toCol)) return false
        val movingPiece = board[fromRow][fromCol]!!
        val captured = board[toRow][toCol]

        // تنفيذ النقلة
        board[toRow][toCol] = movingPiece
        board[fromRow][fromCol] = null

        // ترقية البيدق
        if (movingPiece.type == PieceType.PAWN && (toRow == 0 || toRow == 7)) {
            board[toRow][toCol] = Piece(PieceType.QUEEN, movingPiece.color)
        }

        // التحقق من كش ملك
        val opponentKing = findKing(if (movingPiece.color == Color.WHITE) Color.BLACK else Color.WHITE)
        if (opponentKing != null && isSquareAttacked(opponentKing.first, opponentKing.second, movingPiece.color)) {
            gameOver = true
            winner = movingPiece.color
        }

        // تبديل الدور
        currentTurn = if (currentTurn == Color.WHITE) Color.BLACK else Color.WHITE
        return true
    }

    fun findKing(color: Color): Pair<Int, Int>? {
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = board[r][c]
                if (piece?.type == PieceType.KING && piece.color == color) {
                    return r to c
                }
            }
        }
        return null
    }

    fun isSquareAttacked(row: Int, col: Int, byColor: Color): Boolean {
        // فحص الهجمات من جميع القطع
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = board[r][c] ?: continue
                if (piece.color != byColor) continue
                // محاكاة الحركة
                if (isLegalMove(r, c, row, col)) return true
            }
        }
        return false
    }

    fun getLegalMoves(fromRow: Int, fromCol: Int): List<Move> {
        val moves = mutableListOf<Move>()
        for (r in 0..7) {
            for (c in 0..7) {
                if (isLegalMove(fromRow, fromCol, r, c)) {
                    moves.add(Move(fromRow, fromCol, r, c))
                }
            }
        }
        return moves
    }

    fun reset() = setupBoard()
}
