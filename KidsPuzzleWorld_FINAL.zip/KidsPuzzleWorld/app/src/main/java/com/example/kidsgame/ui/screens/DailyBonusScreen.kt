package com.example.kidsgame.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun DailyBonusScreen(navController: NavController) {
    var streak by remember { mutableStateOf(3) }
    var claimedToday by remember { mutableStateOf(false) }
    var claimScale by remember { mutableStateOf(1f) }

    val scale by animateFloatAsState(if (claimedToday) 1.2f else 1f)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎁 المكافأة اليومية") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🔥 $streak أيام متتالية", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(7) { i ->
                    Box(
                        modifier = Modifier.size(44.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (i < streak) "⭐" else "⬜",
                            fontSize = 28.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🎉 مكافآت اليوم", style = MaterialTheme.typography.titleLarge)
                    Text("100 عملة + 5 نجوم", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            claimedToday = true
                        },
                        modifier = Modifier.scale(scale)
                    ) {
                        Text(if (claimedToday) "تم الاستلام ✅" else "استلام المكافأة 🎁")
                    }
                }
            }
        }
    }
}
