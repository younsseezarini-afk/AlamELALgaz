package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay

@Composable
fun PuzzleScreen(navController: NavController, category: String) {
    var currentIndex by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var showResult by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf(60) }
    var gameOver by remember { mutableStateOf(false) }

    // قائمة ألغاز نموذجية حسب الفئة
    val puzzles = when (category) {
        "words" -> listOf(
            Triple("ما هو الشيء الذي له أسنان ولا يعض؟", listOf("المشط", "الكتاب", "القلم", "الكرسي"), 0),
            Triple("ما هو الشيء الذي يمشي بلا أقدام؟", listOf("السحاب", "الرياح", "الماء", "النار"), 2),
            Triple("ما هو الشيء الذي كلما زاد نقص؟", listOf("العمر", "الحب", "المال", "الصبر"), 0)
        )
        "math" -> listOf(
            Triple("كم يساوي 7 + 8؟", listOf("15", "14", "16", "13"), 0),
            Triple("كم يساوي 9 × 3؟", listOf("27", "24", "18", "21"), 0),
            Triple("كم يساوي 20 - 5؟", listOf("15", "14", "16", "13"), 0)
        )
        "logic" -> listOf(
            Triple("3 + 4 × 2 = ؟", listOf("11", "14", "20", "24"), 0),
            Triple("أكمل النمط: 2، 4، 8، 16، ؟", listOf("32", "24", "18", "30"), 0),
            Triple("أي كلمة مختلفة؟", listOf("شمس", "قمر", "نجم", "باب"), 3)
        )
        else -> listOf(
            Triple("ما هذا الإيموجي؟ 🐘", listOf("فيل", "أسد", "حصان", "قطة"), 0),
            Triple("ما هذا الإيموجي؟ 🦋", listOf("فراشة", "نحلة", "عصفور", "دبور"), 0),
            Triple("ما هذا الإيموجي؟ 🐟", listOf("سمكة", "ثعبان", "سلحفاة", "قنديل"), 0)
        )
    }

    val current = puzzles[currentIndex % puzzles.size]

    LaunchedEffect(Unit) {
        while (timeLeft > 0 && !gameOver) {
            delay(1000)
            timeLeft--
            if (timeLeft == 0) {
                gameOver = true
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🧩 لغز") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } },
                actions = {
                    IconButton(onClick = { showHint = !showHint }) { Text("💡") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // المؤقت
            Text("⏱️ $timeLeft", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))

            // السؤال
            Text(current.first, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp))

            if (showHint) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Text("💡 تلميح: فكر في شيء معروف", modifier = Modifier.padding(12.dp))
                }
                Spacer(Modifier.height(12.dp))
            }

            // الخيارات
            current.second.forEachIndexed { index, option ->
                val isCorrect = selected == index && index == current.third
                val isWrong = showResult && selected == index && index != current.third
                Button(
                    onClick = {
                        if (!showResult) {
                            selected = index
                            showResult = true
                            if (index == current.third) {
                                score += 10
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            isCorrect -> MaterialTheme.colorScheme.primary
                            isWrong -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        contentColor = if (isCorrect || isWrong) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text(option, style = MaterialTheme.typography.bodyLarge)
                }
            }

            Spacer(Modifier.height(12.dp))

            // النتيجة
            if (showResult) {
                Text(
                    if (selected == current.third) "✅ صحيح! +10 نقاط" else "❌ خطأ",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (selected == current.third) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    currentIndex++
                    selected = null
                    showResult = false
                    showHint = false
                    if (currentIndex % puzzles.size == 0) {
                        timeLeft = 60
                    }
                }) {
                    Text("التالي ➡️")
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("النقاط: $score", style = MaterialTheme.typography.titleMedium)
        }
    }
}
