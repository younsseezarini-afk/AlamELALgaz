package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.Puzzle
import kotlinx.coroutines.flow.Flow

@Dao
interface PuzzleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(puzzles: List<Puzzle>)
    @Query("SELECT * FROM puzzles WHERE category = :cat AND language = :lang ORDER BY difficulty ASC, id ASC")
    fun getPuzzles(cat: String, lang: String): Flow<List<Puzzle>>
    @Query("SELECT * FROM puzzles WHERE id = :id") suspend fun getPuzzle(id: Int): Puzzle?
    @Query("SELECT * FROM puzzles WHERE isCompleted = 0 AND category = :cat AND language = :lang ORDER BY difficulty ASC LIMIT 10")
    suspend fun getIncompletePuzzles(cat: String, lang: String): List<Puzzle>
    @Update suspend fun update(puzzle: Puzzle)
    @Query("SELECT COUNT(*) FROM puzzles WHERE isCompleted = 1 AND language = :lang") fun getCompletedCount(lang: String): Flow<Int>
    @Query("SELECT COUNT(*) FROM puzzles WHERE language = :lang") fun getTotalCount(lang: String): Flow<Int>
}
