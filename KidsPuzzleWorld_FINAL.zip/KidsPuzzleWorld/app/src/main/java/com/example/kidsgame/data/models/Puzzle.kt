package com.example.kidsgame.data.models
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "puzzles")
data class Puzzle(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // words, math, logic, picture, sequence
    val difficulty: Int, // 1-3
    val question: String,
    val option1: String,
    val option2: String,
    val option3: String,
    val option4: String,
    val correctIndex: Int,
    val hint: String,
    val stars: Int = 0,
    val isCompleted: Boolean = false,
    val attempts: Int = 0,
    val language: String = "ar",
    val timeLimitSeconds: Int = 60
)
