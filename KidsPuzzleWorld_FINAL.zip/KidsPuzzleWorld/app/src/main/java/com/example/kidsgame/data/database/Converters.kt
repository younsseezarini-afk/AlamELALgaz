package com.example.kidsgame.data.database
import androidx.room.TypeConverter

class Converters {
    @TypeConverter fun fromBoolean(v: Boolean): Int = if (v) 1 else 0
    @TypeConverter fun toBoolean(v: Int): Boolean = v == 1
    @TypeConverter fun fromListToString(list: List<Int>): String = list.joinToString(",")
    @TypeConverter fun fromStringToList(str: String): List<Int> = if (str.isEmpty()) emptyList() else str.split(",").map { it.toInt() }
}
