package com.example.kidsgame.data.models
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class Story(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val imageEmoji: String,
    val audioPath: String? = null,
    val isFavorite: Boolean = false,
    val isRead: Boolean = false,
    val language: String = "ar",
    val readingTimeMinutes: Int = 5
)
