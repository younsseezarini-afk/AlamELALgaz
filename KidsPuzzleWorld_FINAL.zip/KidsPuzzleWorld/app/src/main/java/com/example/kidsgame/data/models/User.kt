package com.example.kidsgame.data.models
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "صديق",
    val stars: Int = 0,
    val coins: Int = 100,
    val level: Int = 1,
    val exp: Int = 0,
    val totalGames: Int = 0,
    val totalCorrect: Int = 0,
    val dailyStreak: Int = 0,
    val lastPlayDate: Long = 0,
    val language: String = "ar",
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val darkMode: Boolean = false,
    val avatar: String = "🧸",
    val bio: String = "",
    val isPro: Boolean = false,
    val joinedDate: Long = System.currentTimeMillis()
)
