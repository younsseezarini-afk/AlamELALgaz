package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HomeScreen(navController: NavController) {
    var userName by remember { mutableStateOf("أحمد") }
    var stars by remember { mutableStateOf(1250) }
    var coins by remember { mutableStateOf(3520) }
    var level by remember { mutableStateOf(12) }
    var streak by remember { mutableStateOf(3) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎮 عالم الألغاز والمرح", style = MaterialTheme.typography.headlineSmall) },
                actions = {
                    IconButton(onClick = { navController.navigate("profile") }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Person, contentDescription = null)
                    }
                    IconButton(onClick = { navController.navigate("settings") }) {
                        Icon(androidx.compose.material.icons.Icons.Default.Settings, contentDescription = null)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(8.dp)
        ) {
            // بطاقة المستخدم
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧸 $userName", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("⭐ $stars", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
                            Text("🪙 $coins", color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.titleMedium)
                            Text("📈 المستوى $level", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // المكافأة اليومية
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔥 سلسلة الأيام: $streak")
                        TextButton(onClick = { navController.navigate("dailyBonus") }) {
                            Text("استلام المكافأة 🎁")
                        }
                    }
                }
            }

            // ألعاب الشبكة
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(listOf(
                        "📝" to "كلمات" to "game/words",
                        "🧮" to "حساب" to "game/math",
                        "🧩" to "منطق" to "game/logic",
                        "🖼️" to "صور" to "game/picture",
                        "♟️" to "شطرنج" to "chess",
                        "🧠" to "ذاكرة" to "memory",
                        "⚡" to "حساب سريع" to "quickmath",
                        "📖" to "قصص" to "stories",
                        "🎨" to "رسم" to "drawing",
                        "🏆" to "إنجازات" to "achievements",
                        "📊" to "صدارة" to "leaderboard",
                        "👤" to "ملفي" to "profile"
                    )) { (gameInfo) ->
                        Card(
                            onClick = { navController.navigate(gameInfo.second) },
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(gameInfo.first, style = MaterialTheme.typography.displaySmall)
                                Text(gameInfo.second, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}
