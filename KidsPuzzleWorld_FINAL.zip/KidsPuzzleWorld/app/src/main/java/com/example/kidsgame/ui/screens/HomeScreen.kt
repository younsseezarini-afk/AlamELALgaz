package com.example.kidsgame.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.kidsgame.R

private val Sky = Color(0xFF35BDF3)
private val SkyLight = Color(0xFF8DE2FA)
private val Orange = Color(0xFFFF9D18)
private val Purple = Color(0xFF9D39C7)
private val Blue = Color(0xFF087EDB)
private val White = Color(0xFFFDFEFF)

@Composable
fun HomeScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Sky, SkyLight, Color(0xFFB9EAF5))))
    ) {
        // Decorative sky clouds, kept subtle so the four menu buttons remain the visual focus.
        Cloud(modifier = Modifier.align(Alignment.TopStart).padding(start = 16.dp, top = 72.dp), scale = 1.0f)
        Cloud(modifier = Modifier.align(Alignment.TopEnd).padding(end = 10.dp, top = 112.dp), scale = 0.82f)

        Column(modifier = Modifier.fillMaxSize()) {
            Header(navController)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(Modifier.height(26.dp))

                MenuButton(
                    title = "ألغاز",
                    icon = R.drawable.puzzle_icon_ref,
                    color = Orange,
                    onClick = { navController.navigate("game/logic") }
                )
                Spacer(Modifier.height(12.dp))

                MenuButton(
                    title = "تلوين",
                    icon = R.drawable.palette_icon_ref,
                    color = Purple,
                    onClick = { navController.navigate("drawing") }
                )
                Spacer(Modifier.height(12.dp))

                MenuButton(
                    title = "ألعاب تعليمية",
                    icon = R.drawable.education_icon_ref,
                    color = Blue,
                    onClick = { navController.navigate("game/words") }
                )
                Spacer(Modifier.height(12.dp))

                MenuButton(
                    title = "متجر",
                    icon = R.drawable.shop_icon_ref,
                    color = Orange,
                    onClick = { navController.navigate("dailyBonus") }
                )
            }

            // Green cartoon-like ground, matching the reference composition.
            Ground()
        }
    }
}

@Composable
private fun Header(navController: NavController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatIcon(R.drawable.coins_icon_ref, "150")
        Spacer(Modifier.width(8.dp))
        StatIcon(R.drawable.star_icon_ref, "5")

        Spacer(Modifier.weight(1f))

        Text(
            text = "عالم الألغاز والمرح",
            color = White,
            fontSize = 21.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Spacer(Modifier.width(8.dp))
        IconButton(onClick = { navController.navigate("settings") }) {
            Image(
                painter = painterResource(R.drawable.gear_icon_ref),
                contentDescription = "الإعدادات",
                modifier = Modifier.size(31.dp),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun StatIcon(icon: Int, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(icon),
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.width(2.dp))
        Text(value, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MenuButton(title: String, icon: Int, color: Color, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp),
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(icon),
                contentDescription = title,
                modifier = Modifier.size(46.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
private fun Ground() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(RoundedCornerShape(topStart = 50.dp, topEnd = 50.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF7DD34B), Color(0xFF4AAB35))
                )
            )
    ) {
        Text("🌿   🌼     🌱     🌷   🌿     🌼", modifier = Modifier.align(Alignment.TopCenter), fontSize = 18.sp)
    }
}

@Composable
private fun Cloud(modifier: Modifier, scale: Float) {
    Box(
        modifier = modifier
            .size(width = (72 * scale).dp, height = (30 * scale).dp)
            .clip(RoundedCornerShape(30.dp))
            .background(Color.White.copy(alpha = 0.82f))
    )
}
