package com.example.kidsgame.data.models
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "leaderboard")
data class LeaderboardEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userName: String,
    val avatar: String,
    val score: Int,
    val level: Int,
    val rank: Int = 0
)
