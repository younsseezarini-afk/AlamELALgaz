package com.example.kidsgame.utils

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore("kids_settings")

class PreferencesManager(private val ctx: Context) {
    companion object {
        val LANG = stringPreferencesKey("lang")
        val SOUND = booleanPreferencesKey("sound")
        val MUSIC = booleanPreferencesKey("music")
        val DARK = booleanPreferencesKey("dark")
        val NAME = stringPreferencesKey("name")
        val AVATAR = stringPreferencesKey("avatar")
    }

    suspend fun setLang(lang: String) { ctx.dataStore.edit { it[LANG] = lang } }
    fun getLang(): Flow<String> = ctx.dataStore.data.map { it[LANG] ?: "ar" }
    suspend fun setSound(v: Boolean) { ctx.dataStore.edit { it[SOUND] = v } }
    fun getSound(): Flow<Boolean> = ctx.dataStore.data.map { it[SOUND] ?: true }
    suspend fun setMusic(v: Boolean) { ctx.dataStore.edit { it[MUSIC] = v } }
    fun getMusic(): Flow<Boolean> = ctx.dataStore.data.map { it[MUSIC] ?: true }
    suspend fun setDark(v: Boolean) { ctx.dataStore.edit { it[DARK] = v } }
    fun getDark(): Flow<Boolean> = ctx.dataStore.data.map { it[DARK] ?: false }
    suspend fun setName(name: String) { ctx.dataStore.edit { it[NAME] = name } }
    fun getName(): Flow<String> = ctx.dataStore.data.map { it[NAME] ?: "صديق" }
    suspend fun setAvatar(avatar: String) { ctx.dataStore.edit { it[AVATAR] = avatar } }
    fun getAvatar(): Flow<String> = ctx.dataStore.data.map { it[AVATAR] ?: "🧸" }
}
