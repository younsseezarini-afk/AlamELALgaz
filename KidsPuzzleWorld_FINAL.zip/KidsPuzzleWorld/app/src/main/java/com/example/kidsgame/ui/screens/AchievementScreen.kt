package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun AchievementScreen(navController: NavController) {
    val achievements = listOf(
        Triple("🌟", "البداية", "أكمل أول لغز", true),
        Triple("🏆", "المثابر", "أكمل 10 ألغاز", true),
        Triple("⭐", "النجم", "اجمع 50 نجمة", true),
        Triple("👑", "البطل", "اجمع 100 نجمة", false),
        Triple("🧠", "المحترف", "أكمل 20 لغزاً", true),
        Triple("🎓", "العبقري", "أكمل 50 لغزاً", false),
        Triple("♟️", "سيد الشطرنج", "الفوز في 5 مباريات شطرنج", false),
        Triple("🧩", "ملك الذاكرة", "أكمل 10 جولات ذاكرة", false)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🏆 الإنجازات") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(achievements) { (icon, name, desc, unlocked) ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = if (unlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(icon, fontSize = 28.sp)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(name, style = MaterialTheme.typography.titleMedium)
                                Text(desc, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Text(if (unlocked) "✅" else "🔒", fontSize = 24.sp)
                    }
                }
            }
        }
    }
}
