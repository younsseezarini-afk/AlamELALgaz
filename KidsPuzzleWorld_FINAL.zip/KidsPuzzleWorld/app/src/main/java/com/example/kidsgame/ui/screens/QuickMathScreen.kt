package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlin.random.Random

@Composable
fun QuickMathScreen(navController: NavController) {
    var a by remember { mutableStateOf(Random.nextInt(1, 10)) }
    var b by remember { mutableStateOf(Random.nextInt(1, 10)) }
    var op by remember { mutableStateOf("+") }
    var result by remember { mutableStateOf(a + b) }
    var correct by remember { mutableStateOf(0) }
    var incorrect by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf(30) }

    // مؤقت (بسيط)
    LaunchedEffect(Unit) {
        while (timeLeft > 0) {
            kotlinx.coroutines.delay(1000)
            timeLeft--
        }
    }

    fun newQuestion() {
        a = Random.nextInt(1, 10)
        b = Random.nextInt(1, 10)
        op = listOf("+", "-", "×")[Random.nextInt(3)]
        result = when (op) {
            "+" -> a + b
            "-" -> a - b
            else -> a * b
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("⚡ حساب سريع") }, navigationIcon = {
                IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") }
            })
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("⏱️ $timeLeft", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Text("$a $op $b = ؟", style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val options = listOf(result, result + 1, result - 1, result + 2).shuffled()
                options.forEach { option ->
                    Button(
                        onClick = {
                            if (option == result) correct++ else incorrect++
                            newQuestion()
                        },
                        modifier = Modifier.size(60.dp)
                    ) {
                        Text("$option", fontSize = 24.sp)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("✅ $correct   ❌ $incorrect", style = MaterialTheme.typography.titleLarge)
        }
    }
}
