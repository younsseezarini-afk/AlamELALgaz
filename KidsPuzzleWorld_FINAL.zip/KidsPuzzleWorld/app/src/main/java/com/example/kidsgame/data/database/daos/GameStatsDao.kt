package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.GameStats
import kotlinx.coroutines.flow.Flow

@Dao
interface GameStatsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(stats: GameStats)
    @Query("SELECT * FROM game_stats WHERE gameType = :gameType") fun getStats(gameType: String): Flow<GameStats?>
    @Query("UPDATE game_stats SET totalPlayed = totalPlayed + 1 WHERE gameType = :gameType") suspend fun incrementPlayed(gameType: String)
    @Query("UPDATE game_stats SET totalWins = totalWins + 1 WHERE gameType = :gameType") suspend fun incrementWins(gameType: String)
    @Query("UPDATE game_stats SET totalTimeMillis = totalTimeMillis + :time WHERE gameType = :gameType") suspend fun addTime(gameType: String, time: Long)
    @Query("UPDATE game_stats SET bestScore = MAX(bestScore, :score) WHERE gameType = :gameType") suspend fun updateBestScore(gameType: String, score: Int)
    @Query("UPDATE game_stats SET lastScore = :score WHERE gameType = :gameType") suspend fun updateLastScore(gameType: String, score: Int)
    @Query("UPDATE game_stats SET highestLevel = MAX(highestLevel, :level) WHERE gameType = :gameType") suspend fun updateHighestLevel(gameType: String, level: Int)
}
