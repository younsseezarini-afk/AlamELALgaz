package com.example.kidsgame.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SettingsScreen(navController: NavController) {
    var sound by remember { mutableStateOf(true) }
    var music by remember { mutableStateOf(true) }
    var dark by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf("ar") }
    var vibration by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("⚙️ الإعدادات") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("🎵 الصوت", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("المؤثرات الصوتية")
                Spacer(Modifier.weight(1f))
                Switch(checked = sound, onCheckedChange = { sound = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الموسيقى الخلفية")
                Spacer(Modifier.weight(1f))
                Switch(checked = music, onCheckedChange = { music = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الاهتزاز")
                Spacer(Modifier.weight(1f))
                Switch(checked = vibration, onCheckedChange = { vibration = it })
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Text("🎨 المظهر", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("الوضع الليلي")
                Spacer(Modifier.weight(1f))
                Switch(checked = dark, onCheckedChange = { dark = it })
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Text("🌐 اللغة", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { lang = "ar" }) { Text("عربي") }
                Button(onClick = { lang = "en" }) { Text("English") }
                Button(onClick = { lang = "fr" }) { Text("Français") }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Text("🔔 الإشعارات", style = MaterialTheme.typography.titleLarge)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("إشعارات المكافآت")
                Spacer(Modifier.weight(1f))
                Switch(checked = notifications, onCheckedChange = { notifications = it })
            }

            Spacer(Modifier.height(24.dp))
            Button(onClick = { navController.navigate("profile") }) {
                Text("الملف الشخصي")
            }
            Button(onClick = { navController.popBackStack() }) {
                Text("عودة")
            }
        }
    }
}
