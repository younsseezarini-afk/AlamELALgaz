package com.example.kidsgame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.lifecycleScope
import com.example.kidsgame.data.database.AppDatabase
import com.example.kidsgame.data.repository.GameRepository
import com.example.kidsgame.ui.navigation.NavGraph
import com.example.kidsgame.ui.theme.KidsGameTheme
import com.example.kidsgame.utils.LanguageManager
import com.example.kidsgame.utils.PreferencesManager
import com.example.kidsgame.utils.SoundManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject lateinit var prefs: PreferencesManager
    @Inject lateinit var repo: GameRepository
    private lateinit var sound: SoundManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sound = SoundManager(this)
        lifecycleScope.launch {
            val lang = prefs.getLang().collectAsState(initial = "ar").value
            LanguageManager.setLocale(this@MainActivity, lang)
            repo.initData()
        }
        setContent {
            val dark = prefs.getDark().collectAsState(initial = false).value
            KidsGameTheme(dark = dark) {
                NavGraph()
            }
        }
        lifecycleScope.launch { sound.playBg() }
    }

    override fun onPause() { super.onPause(); sound.stopBg() }
    override fun onResume() { super.onResume(); sound.playBg() }
    override fun onDestroy() { super.onDestroy(); sound.release() }
}
