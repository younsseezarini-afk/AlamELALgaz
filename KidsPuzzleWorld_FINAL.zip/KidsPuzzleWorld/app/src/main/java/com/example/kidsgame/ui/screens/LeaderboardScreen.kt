package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun LeaderboardScreen(navController: NavController) {
    val entries = listOf(
        Triple("🥇", "أحمد الصغير", 12500),
        Triple("🥈", "سارة الذكية", 12000),
        Triple("🥉", "خالد المحترف", 9800),
        Triple("4️⃣", "نور", 7500),
        Triple("5️⃣", "ليلى", 6200),
        Triple("6️⃣", "يوسف", 5000),
        Triple("7️⃣", "مريم", 4000)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🏆 لوحة الصدارة") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(entries) { (rank, name, score) ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = if (rank == "🥇") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(rank, fontSize = 24.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(name, style = MaterialTheme.typography.titleMedium)
                        }
                        Text("⭐ $score", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
