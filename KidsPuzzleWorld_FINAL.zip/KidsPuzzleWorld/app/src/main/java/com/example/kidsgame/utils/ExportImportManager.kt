package com.example.kidsgame.utils

import android.content.Context
import org.json.JSONObject
import java.io.File

class ExportImportManager(private val ctx: Context) {
    fun exportUserData(userData: String): Boolean {
        return try {
            val file = File(ctx.filesDir, "user_data.json")
            file.writeText(userData)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun importUserData(): String? {
        return try {
            val file = File(ctx.filesDir, "user_data.json")
            if (file.exists()) file.readText() else null
        } catch (e: Exception) {
            null
        }
    }

    fun parseUserJson(json: String): JSONObject {
        return JSONObject(json)
    }
}
