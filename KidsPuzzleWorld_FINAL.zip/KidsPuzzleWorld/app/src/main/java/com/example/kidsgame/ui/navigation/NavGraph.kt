package com.example.kidsgame.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.kidsgame.ui.screens.*
import com.example.kidsgame.ui.settings.SettingsScreen

@Composable
fun NavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }
        composable("game/{category}") { backStack ->
            val cat = backStack.arguments?.getString("category") ?: "words"
            PuzzleScreen(navController, cat)
        }
        composable("chess") { ChessScreen(navController) }
        composable("memory") { MemoryGameScreen(navController) }
        composable("quickmath") { QuickMathScreen(navController) }
        composable("stories") { StoryScreen(navController) }
        composable("dailyBonus") { DailyBonusScreen(navController) }
        composable("achievements") { AchievementScreen(navController) }
        composable("leaderboard") { LeaderboardScreen(navController) }
        composable("profile") { ProfileScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
        composable("drawing") { DrawingScreen(navController) }
    }
}
