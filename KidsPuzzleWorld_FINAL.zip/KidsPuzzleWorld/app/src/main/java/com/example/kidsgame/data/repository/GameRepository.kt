package com.example.kidsgame.data.repository
import com.example.kidsgame.data.database.AppDatabase
import com.example.kidsgame.data.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
class GameRepository(private val db: AppDatabase) {

    // ===== User =====
    suspend fun getOrCreateUser(name: String): User {
        val existing = db.userDao().getUser().firstOrNull()
        return existing ?: run {
            val user = User(name = name)
            db.userDao().insert(user)
            user
        }
    }
    fun getUser(): Flow<User?> = db.userDao().getUser()

    suspend fun addStars(id: Int, stars: Int) {
        val user = db.userDao().getUserById(id) ?: return
        db.userDao().updateStars(id, user.stars + stars)
    }

    suspend fun addCoins(id: Int, coins: Int) {
        val user = db.userDao().getUserById(id) ?: return
        db.userDao().updateCoins(id, user.coins + coins)
    }

    suspend fun addExp(id: Int, exp: Int) {
        val user = db.userDao().getUserById(id) ?: return
        val newExp = user.exp + exp
        val newLevel = 1 + (newExp / 100)
        db.userDao().updateExp(id, newExp)
        if (newLevel > user.level) {
            db.userDao().updateLevel(id, newLevel)
            // مكافأة ترقية
            db.userDao().updateCoins(id, user.coins + 50)
        }
    }

    suspend fun incrementGames(id: Int) = db.userDao().incrementGames(id)
    suspend fun addCorrect(id: Int, correct: Int) = db.userDao().addCorrect(id, correct)

    suspend fun updateStreak(id: Int) {
        val user = db.userDao().getUserById(id) ?: return
        val today = System.currentTimeMillis() / (24 * 60 * 60 * 1000)
        val last = user.lastPlayDate / (24 * 60 * 60 * 1000)
        val streak = when {
            today == last -> user.dailyStreak
            today == last + 1 -> user.dailyStreak + 1
            else -> 1
        }
        db.userDao().updateStreak(id, streak, System.currentTimeMillis())
    }

    suspend fun updateLanguage(id: Int, lang: String) = db.userDao().updateLanguage(id, lang)
    suspend fun updateSound(id: Int, sound: Boolean) = db.userDao().updateSound(id, sound)
    suspend fun updateMusic(id: Int, music: Boolean) = db.userDao().updateMusic(id, music)
    suspend fun updateDarkMode(id: Int, dark: Boolean) = db.userDao().updateDarkMode(id, dark)
    suspend fun updateAvatar(id: Int, avatar: String) = db.userDao().updateAvatar(id, avatar)
    suspend fun updateName(id: Int, name: String) = db.userDao().updateName(id, name)

    // ===== Puzzles =====
    fun getPuzzles(category: String, lang: String): Flow<List<Puzzle>> =
        db.puzzleDao().getPuzzles(category, lang)

    suspend fun completePuzzle(puzzleId: Int, stars: Int) {
        val puzzle = db.puzzleDao().getPuzzle(puzzleId) ?: return
        if (!puzzle.isCompleted) {
            val updated = puzzle.copy(stars = stars, isCompleted = true)
            db.puzzleDao().update(updated)
            val user = db.userDao().getUser().firstOrNull() ?: return
            db.userDao().addCorrect(user.id, 1)
            db.userDao().updateStars(user.id, user.stars + stars)
            db.userDao().updateCoins(user.id, user.coins + stars * 5)
            db.userDao().incrementGames(user.id)
            addExp(user.id, stars * 10)
        }
    }

    suspend fun recordAttempt(puzzleId: Int) {
        val p = db.puzzleDao().getPuzzle(puzzleId) ?: return
        db.puzzleDao().update(p.copy(attempts = p.attempts + 1))
    }

    // ===== Stories =====
    fun getStories(lang: String): Flow<List<Story>> = db.storyDao().getStories(lang)
    suspend fun markStoryRead(id: Int) = db.storyDao().markAsRead(id)
    suspend fun setStoryFavorite(id: Int, fav: Boolean) = db.storyDao().setFavorite(id, fav)

    // ===== Achievements =====
    fun getAchievements(): Flow<List<Achievement>> = db.achievementDao().getAll()
    suspend fun updateAchievementProgress(id: Int, progress: Int) {
        val a = db.achievementDao().getById(id) ?: return
        val newProgress = minOf(progress, a.target)
        db.achievementDao().updateProgress(id, newProgress)
        if (newProgress >= a.target && !a.isUnlocked) {
            db.achievementDao().unlock(id)
            val user = db.userDao().getUser().firstOrNull() ?: return
            db.userDao().updateCoins(user.id, user.coins + a.rewardCoins)
            db.userDao().updateStars(user.id, user.stars + a.rewardStars)
        }
    }

    // ===== Game Stats =====
    fun getGameStats(gameType: String): Flow<GameStats?> = db.gameStatsDao().getStats(gameType)
    suspend fun recordGamePlay(gameType: String, win: Boolean, timeMillis: Long, score: Int, levelReached: Int) {
        db.gameStatsDao().incrementPlayed(gameType)
        if (win) db.gameStatsDao().incrementWins(gameType)
        db.gameStatsDao().addTime(gameType, timeMillis)
        db.gameStatsDao().updateBestScore(gameType, score)
        db.gameStatsDao().updateLastScore(gameType, score)
        db.gameStatsDao().updateHighestLevel(gameType, levelReached)
    }

    // ===== Leaderboard =====
    fun getLeaderboard(): Flow<List<LeaderboardEntry>> = db.leaderboardDao().getAll()
    suspend fun updateLeaderboard(user: User) {
        val entry = LeaderboardEntry(
            userName = user.name,
            avatar = user.avatar,
            score = user.stars + user.coins / 10,
            level = user.level
        )
        db.leaderboardDao().insert(entry)
    }

    // ===== Initial Data =====
    suspend fun initData() {
        if (db.puzzleDao().getPuzzles("words", "ar").firstOrNull().isNullOrEmpty()) {
            // 150 لغز عربي
            val wordsPuzzles = mutableListOf<Puzzle>()
            val wordQuestions = listOf(
                Triple("ما هو الشيء الذي له أسنان ولا يعض؟", listOf("المشط", "الكتاب", "القلم", "الكرسي"), 0),
                Triple("ما هو الشيء الذي يمشي بلا أقدام؟", listOf("السحاب", "الرياح", "الماء", "النار"), 2),
                Triple("ما هو الشيء الذي كلما زاد نقص؟", listOf("العمر", "الحب", "المال", "الصبر"), 0),
                Triple("ما هو الشيء الذي له رأس ولا عقل؟", listOf("الدبوس", "الكتاب", "القلم", "الطاولة"), 2),
                Triple("ما هو الشيء الذي تأكل منه ولا تأكله؟", listOf("الطبق", "الملعقة", "الشمعة", "الزجاجة"), 0),
                Triple("ما هو البيت الذي ليس فيه أبواب ولا نوافذ؟", listOf("بيت الشعر", "بيت النمل", "بيت العنكبوت", "بيت الصحراء"), 0),
                Triple("ما هو الشيء الذي يكتب ولا يقرأ؟", listOf("القلم", "الورق", "الكتاب", "الدفتر"), 0),
                Triple("ما هو الشيء الذي يسمع بلا أذن؟", listOf("الهاتف", "الراديو", "التلفاز", "الجرس"), 1),
                Triple("ما هو الشيء الذي يعيدك إلى الصغر؟", listOf("الذاكرة", "المرآة", "الصورة", "اللعب"), 0),
                Triple("ما هو الشيء الذي ينام ولا يستيقظ؟", listOf("الحجر", "الطفل", "الحيوان", "النجم"), 0),
                Triple("ما هو الشيء الذي له عين ولا يرى؟", listOf("الإبرة", "الشمعة", "الزجاجة", "القفل"), 0),
                Triple("ما هو الشيء الذي ينبض بلا قلب؟", listOf("الساعة", "القلب الصناعي", "الموبايل", "الجرس"), 0),
                Triple("ما هو الشيء الذي يذهب ولا يعود؟", listOf("الوقت", "المال", "الصديق", "القطار"), 0),
                Triple("ما هو الشيء الذي يكبر كلما أخذت منه؟", listOf("الحفرة", "الجبل", "الشجرة", "النهر"), 0),
                Triple("ما هو الشيء الذي له أوراق وليس شجرة؟", listOf("الكتاب", "الدفتر", "المجلة", "الرسالة"), 0)
            )
            for (i in 0..149) {
                val (q, opts, correct) = wordQuestions[i % wordQuestions.size]
                wordsPuzzles.add(
                    Puzzle(
                        category = "words",
                        difficulty = if (i < 50) 1 else if (i < 100) 2 else 3,
                        question = q,
                        option1 = opts[0],
                        option2 = opts[1],
                        option3 = opts[2],
                        option4 = opts[3],
                        correctIndex = correct,
                        hint = "فكر في شيء معروف...",
                        language = "ar",
                        timeLimitSeconds = if (i < 50) 60 else if (i < 100) 45 else 30
                    )
                )
            }
            db.puzzleDao().insertAll(wordsPuzzles)

            // 150 لغز حساب
            val mathPuzzles = mutableListOf<Puzzle>()
            for (i in 0..149) {
                val a = (1..20).random()
                val b = (1..10).random()
                val op = listOf("+", "-", "×")[i % 3]
                val result = when (op) {
                    "+" -> a + b
                    "-" -> a - b
                    else -> a * b
                }
                val correctIndex = (0..3).random()
                val options = mutableListOf(result, result + 1, result - 1, result + 2)
                options.shuffle()
                mathPuzzles.add(
                    Puzzle(
                        category = "math",
                        difficulty = if (i < 50) 1 else if (i < 100) 2 else 3,
                        question = "كم يساوي $a $op $b؟",
                        option1 = options[0].toString(),
                        option2 = options[1].toString(),
                        option3 = options[2].toString(),
                        option4 = options[3].toString(),
                        correctIndex = options.indexOf(result),
                        hint = "استخدم الأصابع للعد",
                        language = "ar",
                        timeLimitSeconds = 30
                    )
                )
            }
            db.puzzleDao().insertAll(mathPuzzles)

            // 150 لغز منطق
            val logicPuzzles = mutableListOf<Puzzle>()
            val logicQuestions = listOf(
                Triple("إذا كانت القطة تقول مواء، فماذا يقول الكلب؟", listOf("نباح", "مواء", "صهيل", "زقزقة"), 0),
                Triple("3 + 4 × 2 = ؟", listOf("11", "14", "20", "24"), 0),
                Triple("أكمل النمط: 2، 4، 8، 16، ؟", listOf("32", "24", "18", "30"), 0),
                Triple("ما هو الرقم الذي إذا ضربته في نفسه يعطي 81؟", listOf("9", "8", "7", "6"), 0),
                Triple("أي كلمة مختلفة؟", listOf("شمس", "قمر", "نجم", "باب"), 3),
                Triple("إذا كان اليوم الثلاثاء، فبعد 3 أيام يكون؟", listOf("الجمعة", "الخميس", "السبت", "الأحد"), 0)
            )
            for (i in 0..149) {
                val (q, opts, correct) = logicQuestions[i % logicQuestions.size]
                logicPuzzles.add(
                    Puzzle(
                        category = "logic",
                        difficulty = if (i < 50) 1 else if (i < 100) 2 else 3,
                        question = q,
                        option1 = opts[0],
                        option2 = opts[1],
                        option3 = opts[2],
                        option4 = opts[3],
                        correctIndex = correct,
                        hint = "ركز على التفكير",
                        language = "ar",
                        timeLimitSeconds = 45
                    )
                )
            }
            db.puzzleDao().insertAll(logicPuzzles)

            // 100 لغز صور (إيموجي)
            val picturePuzzles = mutableListOf<Puzzle>()
            for (i in 0..99) {
                picturePuzzles.add(
                    Puzzle(
                        category = "picture",
                        difficulty = if (i < 33) 1 else if (i < 66) 2 else 3,
                        question = "ما هذا الإيموجي؟ 🐘",
                        option1 = "فيل",
                        option2 = "أسد",
                        option3 = "حصان",
                        option4 = "قطة",
                        correctIndex = 0,
                        hint = "حيوان ضخم",
                        language = "ar",
                        timeLimitSeconds = 30
                    )
                )
            }
            db.puzzleDao().insertAll(picturePuzzles)

            // قصص عربية
            db.storyDao().insertAll(listOf(
                Story(title = "السلحفاة الصغيرة", content = "كانت هناك سلحفاة صغيرة تعيش في بركة هادئة، تحلم بزيارة البحر...", imageEmoji = "🐢", language = "ar", readingTimeMinutes = 3),
                Story(title = "الفراشة الجميلة", content = "في حديقة ملونة، ولدت فراشة صغيرة من شرنقة ذهبية...", imageEmoji = "🦋", language = "ar", readingTimeMinutes = 4),
                Story(title = "الأرنب الذكي", content = "في الغابة، عاش أرنب ذكي يحل جميع المشاكل...", imageEmoji = "🐰", language = "ar", readingTimeMinutes = 5),
                Story(title = "النحلة المجتهدة", content = "كانت نحلة تجمع الرحيق من الأزهار طوال اليوم...", imageEmoji = "🐝", language = "ar", readingTimeMinutes = 3)
            ))

            // إنجازات
            db.achievementDao().insertAll(listOf(
                Achievement(name = "البداية", description = "أكمل أول لغز", icon = "🌟", target = 1, rewardCoins = 50, rewardStars = 5),
                Achievement(name = "المثابر", description = "أكمل 10 ألغاز", icon = "🏆", target = 10, rewardCoins = 100, rewardStars = 10),
                Achievement(name = "النجم", description = "اجمع 50 نجمة", icon = "⭐", target = 50, rewardCoins = 200, rewardStars = 20),
                Achievement(name = "البطل", description = "اجمع 100 نجمة", icon = "👑", target = 100, rewardCoins = 500, rewardStars = 50),
                Achievement(name = "المحترف", description = "أكمل 20 لغزاً", icon = "🧠", target = 20, rewardCoins = 150, rewardStars = 15),
                Achievement(name = "العبقري", description = "أكمل 50 لغزاً", icon = "🎓", target = 50, rewardCoins = 400, rewardStars = 40),
                Achievement(name = "سيد الشطرنج", description = "الفوز في 5 مباريات شطرنج", icon = "♟️", target = 5, rewardCoins = 300, rewardStars = 30),
                Achievement(name = "ملك الذاكرة", description = "أكمل 10 جولات ذاكرة", icon = "🧩", target = 10, rewardCoins = 100, rewardStars = 10)
            ))

            // بيانات المتصدرين
            db.leaderboardDao().insertAll(listOf(
                LeaderboardEntry(userName = "أحمد الصغير", avatar = "🦁", score = 12500, level = 15),
                LeaderboardEntry(userName = "سارة الذكية", avatar = "🦄", score = 12000, level = 14),
                LeaderboardEntry(userName = "خالد المحترف", avatar = "🐉", score = 9800, level = 12),
                LeaderboardEntry(userName = "نور", avatar = "🐱", score = 7500, level = 10),
                LeaderboardEntry(userName = "ليلى", avatar = "🌸", score = 6200, level = 9)
            ))

            // ألغاز إنجليزية
            val enPuzzles = wordsPuzzles.take(50).map {
                it.copy(
                    language = "en",
                    question = it.question.replace("ما هو الشيء الذي", "What is the thing that"),
                    option1 = "comb", option2 = "book", option3 = "pen", option4 = "chair",
                    correctIndex = 0
                )
            }
            db.puzzleDao().insertAll(enPuzzles)

            // ألغاز فرنسية
            val frPuzzles = wordsPuzzles.take(50).map {
                it.copy(
                    language = "fr",
                    question = it.question.replace("ما هو الشيء الذي", "Qu'est-ce qui"),
                    option1 = "peigne", option2 = "livre", option3 = "stylo", option4 = "chaise",
                    correctIndex = 0
                )
            }
            db.puzzleDao().insertAll(frPuzzles)
        }
    }
}
