package com.example.kidsgame.utils

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LanguageManager {
    fun setLocale(ctx: Context, lang: String) {
        val loc = Locale(lang)
        Locale.setDefault(loc)
        val config = Configuration(ctx.resources.configuration)
        config.setLocale(loc)
        ctx.resources.updateConfiguration(config, ctx.resources.displayMetrics)
    }
}
