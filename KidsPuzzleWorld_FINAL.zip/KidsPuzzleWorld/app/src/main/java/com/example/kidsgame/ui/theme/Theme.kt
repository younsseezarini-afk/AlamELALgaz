package com.example.kidsgame.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFD700)
val Pink = Color(0xFFFF6B9D)
val Sky = Color(0xFF4FC3F7)
val Green = Color(0xFF66BB6A)
val Orange = Color(0xFFFFA726)
val Purple = Color(0xFFAB47BC)
val Wood = Color(0xFF8B5A2B)
val WoodDark = Color(0xFF5D3A1A)

@Composable
fun KidsGameTheme(dark: Boolean = false, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Gold,
        onPrimary = WoodDark,
        secondary = Sky,
        tertiary = Green,
        background = Color(0xFF1A1A2E),
        surface = Color(0xFF16213E)
    ) else lightColorScheme(
        primary = Pink,
        onPrimary = Color.White,
        secondary = Sky,
        tertiary = Green,
        background = Color(0xFFFFF8E1),
        surface = Color.White,
        onSurface = Color.Black
    )
    MaterialTheme(colorScheme = scheme, typography = KidsTypography, content = content)
}
