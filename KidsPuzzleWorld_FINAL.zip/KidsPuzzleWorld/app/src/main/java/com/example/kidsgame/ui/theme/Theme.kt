package com.example.kidsgame.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFD54F)
val Pink = Color(0xFFFF6B9D)
val Sky = Color(0xFF29B6F6)
val Green = Color(0xFF66C93A)
val Orange = Color(0xFFFFA726)
val Purple = Color(0xFF9B4DCC)
val Wood = Color(0xFF8B5A2B)
val WoodDark = Color(0xFF173B54)

@Composable
fun KidsGameTheme(dark: Boolean = false, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Gold,
        onPrimary = WoodDark,
        secondary = Sky,
        tertiary = Green,
        background = Color(0xFF062C46),
        surface = Color(0xFF0B4569)
    ) else lightColorScheme(
        primary = Sky,
        onPrimary = Color.White,
        secondary = Purple,
        tertiary = Green,
        background = Color(0xFFB3E5FC),
        surface = Color.White,
        onSurface = Color(0xFF12344A)
    )
    MaterialTheme(colorScheme = scheme, typography = KidsTypography, content = content)
}
