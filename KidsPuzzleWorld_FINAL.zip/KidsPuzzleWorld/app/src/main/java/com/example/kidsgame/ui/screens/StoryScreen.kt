package com.example.kidsgame.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StoryScreen(navController: NavController) {
    val stories = listOf(
        "🐢" to "السلحفاة الصغيرة" to "كانت هناك سلحفاة صغيرة تعيش في بركة هادئة...",
        "🦋" to "الفراشة الجميلة" to "في حديقة ملونة، ولدت فراشة صغيرة من شرنقة ذهبية...",
        "🐰" to "الأرنب الذكي" to "في الغابة، عاش أرنب ذكي يحل جميع المشاكل...",
        "🐝" to "النحلة المجتهدة" to "كانت نحلة تجمع الرحيق من الأزهار طوال اليوم..."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📖 قصص") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            items(stories) { (emoji, title, content) ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp)) {
                        Text(emoji, fontSize = 40.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.titleLarge)
                            Text(content, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = {}) {
                                Text("اقرأ المزيد")
                            }
                        }
                    }
                }
            }
        }
    }
}
