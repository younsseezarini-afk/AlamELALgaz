package com.example.kidsgame.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

class SoundManager(private val ctx: Context) {
    private var pool: SoundPool? = null
    private var player: MediaPlayer? = null
    private var soundEnabled = true
    private var musicEnabled = true

    init {
        val aa = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(10).setAudioAttributes(aa).build()
        // هنا يمكن تحميل ملفات صوتية من res/raw
        // pool?.load(ctx, R.raw.click, 1)
    }

    fun setSoundEnabled(v: Boolean) { soundEnabled = v }
    fun setMusicEnabled(v: Boolean) { musicEnabled = v }

    fun playClick() { if (soundEnabled) pool?.play(1, 0.6f, 0.6f, 1, 0, 1f) }
    fun playWin() { if (soundEnabled) pool?.play(2, 0.6f, 0.6f, 1, 0, 1f) }
    fun playLose() { if (soundEnabled) pool?.play(3, 0.6f, 0.6f, 1, 0, 1f) }

    fun playBg() {
        if (!musicEnabled) return
        if (player == null) {
            // player = MediaPlayer.create(ctx, R.raw.bg_music)
            player?.isLooping = true
            player?.setVolume(0.3f, 0.3f)
        }
        player?.start()
    }

    fun stopBg() { player?.pause() }
    fun release() { pool?.release(); player?.release() }
}
