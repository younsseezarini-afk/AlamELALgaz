package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.Story
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(stories: List<Story>)
    @Query("SELECT * FROM stories WHERE language = :lang ORDER BY id") fun getStories(lang: String): Flow<List<Story>>
    @Query("SELECT * FROM stories WHERE id = :id") suspend fun getStory(id: Int): Story?
    @Update suspend fun update(story: Story)
    @Query("UPDATE stories SET isRead = 1 WHERE id = :id") suspend fun markAsRead(id: Int)
    @Query("UPDATE stories SET isFavorite = :fav WHERE id = :id") suspend fun setFavorite(id: Int, fav: Boolean)
}
