package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(user: User)
    @Query("SELECT * FROM users LIMIT 1") fun getUser(): Flow<User?>
    @Query("SELECT * FROM users WHERE id = :id") suspend fun getUserById(id: Int): User?
    @Query("UPDATE users SET stars = :stars WHERE id = :id") suspend fun updateStars(id: Int, stars: Int)
    @Query("UPDATE users SET coins = :coins WHERE id = :id") suspend fun updateCoins(id: Int, coins: Int)
    @Query("UPDATE users SET level = :level WHERE id = :id") suspend fun updateLevel(id: Int, level: Int)
    @Query("UPDATE users SET exp = :exp WHERE id = :id") suspend fun updateExp(id: Int, exp: Int)
    @Query("UPDATE users SET dailyStreak = :streak, lastPlayDate = :date WHERE id = :id")
    suspend fun updateStreak(id: Int, streak: Int, date: Long)
    @Query("UPDATE users SET language = :lang WHERE id = :id") suspend fun updateLanguage(id: Int, lang: String)
    @Query("UPDATE users SET soundEnabled = :sound WHERE id = :id") suspend fun updateSound(id: Int, sound: Boolean)
    @Query("UPDATE users SET musicEnabled = :music WHERE id = :id") suspend fun updateMusic(id: Int, music: Boolean)
    @Query("UPDATE users SET darkMode = :dark WHERE id = :id") suspend fun updateDarkMode(id: Int, dark: Boolean)
    @Query("UPDATE users SET totalGames = totalGames + 1 WHERE id = :id") suspend fun incrementGames(id: Int)
    @Query("UPDATE users SET totalCorrect = totalCorrect + :correct WHERE id = :id") suspend fun addCorrect(id: Int, correct: Int)
    @Query("UPDATE users SET avatar = :avatar WHERE id = :id") suspend fun updateAvatar(id: Int, avatar: String)
    @Query("UPDATE users SET name = :name WHERE id = :id") suspend fun updateName(id: Int, name: String)
    @Query("DELETE FROM users WHERE id = :id") suspend fun delete(id: Int)
}
