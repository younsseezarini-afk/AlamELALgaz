package com.example.kidsgame.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun DrawingScreen(navController: NavController) {
    var currentColor by remember { mutableStateOf(Color.Red) }
    var strokeWidth by remember { mutableStateOf(5f) }
    var paths by remember { mutableStateOf(mutableListOf<Pair<Path, Color>>()) }
    var currentPath by remember { mutableStateOf<Path?>(null) }

    val colors = listOf(Color.Red, Color.Blue, Color.Green, Color.Black, Color.Yellow, Color.Purple, Color.Orange, Color.Pink)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎨 الرسم") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(8.dp)) {
            // اللوحة
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White)
                    .border(2.dp, Color.Gray)
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.first()
                                if (change.pressed) {
                                    if (currentPath == null) {
                                        currentPath = Path().apply { moveTo(change.position.x, change.position.y) }
                                    } else {
                                        currentPath?.lineTo(change.position.x, change.position.y)
                                    }
                                } else if (currentPath != null) {
                                    paths = paths + (currentPath!! to currentColor)
                                    currentPath = null
                                }
                            }
                        }
                    }
            ) {
                // رسم المسارات السابقة
                paths.forEach { (path, color) ->
                    drawPath(
                        path = path,
                        color = color,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth)
                    )
                }
                // رسم المسار الحالي
                currentPath?.let { path ->
                    drawPath(
                        path = path,
                        color = currentColor,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth)
                    )
                }
            }

            // أزرار الألوان
            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                colors.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(color, androidx.compose.foundation.shape.CircleShape)
                            .clickable { currentColor = color }
                    )
                }
            }

            // زر مسح
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { paths = mutableListOf() }) {
                    Text("🗑️ مسح")
                }
            }
        }
    }
}
