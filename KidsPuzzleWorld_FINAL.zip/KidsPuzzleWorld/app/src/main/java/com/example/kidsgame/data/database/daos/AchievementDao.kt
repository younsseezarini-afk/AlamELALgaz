package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.Achievement
import kotlinx.coroutines.flow.Flow

@Dao
interface AchievementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(achievements: List<Achievement>)
    @Query("SELECT * FROM achievements ORDER BY id") fun getAll(): Flow<List<Achievement>>
    @Query("SELECT * FROM achievements WHERE id = :id") suspend fun getById(id: Int): Achievement?
    @Update suspend fun update(achievement: Achievement)
    @Query("UPDATE achievements SET progress = :progress WHERE id = :id") suspend fun updateProgress(id: Int, progress: Int)
    @Query("UPDATE achievements SET isUnlocked = 1 WHERE id = :id") suspend fun unlock(id: Int)
}
