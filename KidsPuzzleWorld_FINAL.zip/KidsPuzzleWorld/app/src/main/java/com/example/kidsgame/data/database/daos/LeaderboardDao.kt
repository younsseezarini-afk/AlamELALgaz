package com.example.kidsgame.data.database
import androidx.room.*
import com.example.kidsgame.data.models.LeaderboardEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface LeaderboardDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(entries: List<LeaderboardEntry>)
    @Query("SELECT * FROM leaderboard ORDER BY score DESC LIMIT 50") fun getTop50(): Flow<List<LeaderboardEntry>>
    @Query("SELECT * FROM leaderboard ORDER BY score DESC") fun getAll(): Flow<List<LeaderboardEntry>>
    @Query("DELETE FROM leaderboard") suspend fun clear()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(entry: LeaderboardEntry)
}
