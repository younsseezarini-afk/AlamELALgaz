package com.example.kidsgame.data.models
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_stats")
data class GameStats(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val gameType: String, // chess, memory, math...
    val totalPlayed: Int = 0,
    val totalWins: Int = 0,
    val totalTimeMillis: Long = 0,
    val bestScore: Int = 0,
    val lastScore: Int = 0,
    val highestLevel: Int = 1
)
