# KidsPuzzleWorld - CI Ready

This package contains the complete Android project plus a lightweight `gradlew` launcher for GitHub Actions.

The launcher downloads Gradle 8.2 automatically on the GitHub runner, so the project does not require Android Studio on your iPhone.

Build command:

    ./gradlew assembleDebug

The debug APK is produced at:

    app/build/outputs/apk/debug/app-debug.apk
