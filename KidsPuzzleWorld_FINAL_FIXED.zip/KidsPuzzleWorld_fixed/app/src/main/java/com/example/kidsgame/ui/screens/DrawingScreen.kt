package com.example.kidsgame.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun DrawingScreen(navController: NavController) {
    var currentColor by remember { mutableStateOf(Color.Red) }
    var strokeWidth by remember { mutableStateOf(5f) }
    var paths by remember { mutableStateOf<List<Pair<Path, Color>>>(emptyList()) }
    var currentPath by remember { mutableStateOf<Path?>(null) }

    val colors = listOf(
        Color.Red, Color.Blue, Color.Green, Color.Black,
        Color.Yellow, Color(0xFF9C27B0), Color(0xFFFF9800), Color(0xFFE91E63)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("🎨 الرسم") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("⬅️") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(8.dp)) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White)
                    .border(2.dp, Color.Gray)
                    .pointerInput(currentColor) {
                        detectDragGestures(
                            onDragStart = { position ->
                                currentPath = Path().apply { moveTo(position.x, position.y) }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                currentPath?.lineTo(change.position.x, change.position.y)
                            },
                            onDragEnd = {
                                currentPath?.let { path ->
                                    paths = paths + (path to currentColor)
                                }
                                currentPath = null
                            },
                            onDragCancel = {
                                currentPath = null
                            }
                        )
                    }
            ) {
                paths.forEach { (path, color) ->
                    drawPath(path, color, style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth))
                }
                currentPath?.let { path ->
                    drawPath(path, currentColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth))
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                colors.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(color, androidx.compose.foundation.shape.CircleShape)
                            .clickable { currentColor = color }
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Button(onClick = { paths = emptyList(); currentPath = null }) {
                    Text("🗑️ مسح")
                }
            }
        }
    }
}
