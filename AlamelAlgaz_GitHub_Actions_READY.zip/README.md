# AlamelAlgaz

Android puzzle-game project using Kotlin and Jetpack Compose.

## Build APK directly on GitHub — no Android Studio or computer required

1. Create a GitHub repository.
2. Upload all files from this project.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Press **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run.
8. Download the **AlamelAlgaz-APK** artifact.
9. Inside it you will find `app-debug.apk`.

The workflow uses GitHub Actions to install JDK/Android SDK and build the APK on GitHub's servers.

## Local build

If you later use a computer with Android/Java tooling, run:

`./gradlew assembleDebug`

APK output:

`app/build/outputs/apk/debug/app-debug.apk`
