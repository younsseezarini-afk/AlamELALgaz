package com.example.alamelalgaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.example.alamelalgaz.ui.theme.AlamelAlgazTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlamelAlgazTheme { App() } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onPlay = { nav.navigate("levels") },
                onSettings = { nav.navigate("settings") }
            )
        }
        composable("levels") { LevelsScreen(onBack = { nav.popBackStack() }, onGame = { nav.navigate("game") }) }
        composable("game") { GameScreen(onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}

@Composable
fun HomeScreen(onPlay: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("عالم الألغاز", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("ابدأ اللعب") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Settings, null)
            Spacer(Modifier.width(8.dp))
            Text("الإعدادات")
        }
    }
}

@Composable
fun LevelsScreen(onBack: () -> Unit, onGame: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("المراحل", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onGame, modifier = Modifier.fillMaxWidth()) { Text("المرحلة 1") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onBack) { Text("رجوع") }
    }
}

@Composable
fun GameScreen(onBack: () -> Unit) {
    var answer by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("لغز المرحلة 1", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(24.dp))
        Text("ما هو الشيء الذي له أسنان ولا يعض؟")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(value = answer, onValueChange = { answer = it }, label = { Text("إجابتك") })
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            message = if (answer.trim() == "المشط") "إجابة صحيحة 🎉" else "حاول مرة أخرى"
        }) { Text("تحقق") }
        Spacer(Modifier.height(12.dp))
        Text(message)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onBack) { Text("رجوع") }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))
        Text("إعدادات اللعبة")
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onBack) { Text("رجوع") }
    }
}
